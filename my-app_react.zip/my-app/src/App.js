import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  state={
    value: 'This is from status'
  }

  // change the text
  changeText=(newValue)=>{
    this.setState({
      value: newValue
    });
  }
  render() {
    return (
      <div>
        <text>{this.state.value}</text>
        <input type='text' value={this.state.value}
         onChange={(e)=>{this.changeText(e.target.value)}}></input>
        <button onClick={this.changeText}>Change Status</button>
      </div>
    );
  }
}

export default App;
